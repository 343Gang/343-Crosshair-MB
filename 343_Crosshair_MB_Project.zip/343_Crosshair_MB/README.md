# 343 Crosshair MB

Android overlay crosshair app concept/project.

Features:
- 100 selectable crosshair presets (10 families x 10 variants)
- Custom size, opacity and color
- Position nudge controls: left/right/up/down/center
- Touch-through overlay mode
- Portrait + landscape / full sensor
- Display-over-other-apps permission flow
- Dark blue/white/green gaming UI
- Animated 343 CROSSHAIRS intro
- GitHub Actions workflow for free APK build

## Build
Open in Android Studio or push to GitHub and run:
Actions -> Build 343 Crosshair MB APK

The generated debug APK is uploaded as a workflow artifact.

## Important Android behavior
A true touch-through overlay cannot simultaneously receive drag gestures because Android must choose
whether the overlay or the underlying game receives the touch. This project keeps the gameplay area
touch-through and uses directional position controls to move the crosshair without stealing game touches.

## iPhone
An Android APK cannot run on iPhone. iOS needs a separate iOS app and has stricter overlay/system-wide
UI limitations; a direct always-on-top crosshair over arbitrary games is not generally equivalent to Android.
## APK note
This workspace does not have the Android SDK installed, so the APK is not precompiled here. The included GitHub Actions workflow builds the installable APK automatically without a paid service.
