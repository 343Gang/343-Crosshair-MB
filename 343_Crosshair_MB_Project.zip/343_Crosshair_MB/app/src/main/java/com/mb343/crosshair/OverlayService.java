package com.mb343.crosshair;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import java.util.*;

public class OverlayService extends Service {
    WindowManager wm; CrosshairView view; boolean showing=false;
    int x=0,y=0;

    @Override public void onCreate(){
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel("343","343 Crosshair",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(343, notification()); else startForeground(343, notification());
    }

    Notification notification(){
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,"343").setContentTitle("343 Crosshair MB")
                .setContentText("Crosshair overlay service is active").setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true).build();
    }

    @Override public int onStartCommand(Intent intent,int flags,int id){
        if(intent!=null && "TOGGLE".equals(intent.getAction())){
            if(showing) hide(); else show();
        } else if(intent!=null && "UPDATE".equals(intent.getAction()) && showing) refresh();
        else if(intent!=null && "NUDGE".equals(intent.getAction())) nudge(intent.getStringExtra("dir"));
        return START_STICKY;
    }

    void show(){
        if(!Settings.canDrawOverlays(this)) return;
        if(view==null) view=new CrosshairView(this);
        refreshData();
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(
                500,500,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START; lp.x=x; lp.y=y;
        wm.addView(view,lp); showing=true;
    }

    void hide(){ if(view!=null && showing){wm.removeView(view);showing=false;} }

    void refresh(){
        if(!showing) return;
        refreshData();
        WindowManager.LayoutParams lp=(WindowManager.LayoutParams)view.getLayoutParams();
        lp.x=x;lp.y=y;wm.updateViewLayout(view,lp);
    }

    void refreshData(){
        android.content.SharedPreferences p=getSharedPreferences("dummy",0);
        // MainActivity stores in Activity preferences, so service receives a broadcast-like
        // refresh through the service intent extras when available. Defaults are safe.
        int id=getSharedPreferences("overlay",0).getInt("id",0);
        int size=getSharedPreferences("overlay",0).getInt("size",90);
        int op=getSharedPreferences("overlay",0).getInt("opacity",100);
        int color=getSharedPreferences("overlay",0).getInt("color",Color.WHITE);
        if(view!=null) view.setData(id,size,(int)(255*op/100f),color);
    }

    void nudge(String d){
        int step=12;
        if("←".equals(d)) x-=step;
        if("→".equals(d)) x+=step;
        if("↑".equals(d)) y-=step;
        if("↓".equals(d)) y+=step;
        if("CENTER".equals(d)){x=0;y=0;}
        if(showing){
            WindowManager.LayoutParams lp=(WindowManager.LayoutParams)view.getLayoutParams();
            lp.x=x;lp.y=y;wm.updateViewLayout(view,lp);
        }
    }

    @Override public void onDestroy(){hide();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}