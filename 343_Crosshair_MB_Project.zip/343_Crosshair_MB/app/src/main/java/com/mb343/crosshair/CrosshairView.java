package com.mb343.crosshair;

import android.graphics.*;
import android.view.*;

public class CrosshairView extends View {
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    int style=0, size=90, opacity=255, color=Color.WHITE;

    public CrosshairView(android.content.Context c){super(c); p.setStrokeCap(Paint.Cap.SQUARE);}
    public void setData(int s,int z,int o,int c){style=s;size=z;opacity=o;color=c;invalidate();}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        p.setColor(color); p.setAlpha(opacity); p.setStyle(Paint.Style.STROKE);
        float k=size/100f, w=Math.max(2, size*.045f), gap=size*.16f, len=size*.25f;
        p.setStrokeWidth(w);
        float cx=getWidth()/2f, cy=getHeight()/2f;
        int family=style%10;
        if(family==0) classic(c,cx,cy,k,gap,len);
        else if(family==1) circle(c,cx,cy,k,gap,len);
        else if(family==2) dot(c,cx,cy,k,gap,len);
        else if(family==3) brackets(c,cx,cy,k,gap,len);
        else if(family==4) chevron(c,cx,cy,k,gap,len);
        else if(family==5) x(c,cx,cy,k,gap,len);
        else if(family==6) tShape(c,cx,cy,k,gap,len);
        else if(family==7) square(c,cx,cy,k,gap,len);
        else if(family==8) diamond(c,cx,cy,k,gap,len);
        else spinner(c,cx,cy,k,gap,len);
    }

    void line(Canvas c,float x1,float y1,float x2,float y2){c.drawLine(x1,y1,x2,y2,p);}
    void classic(Canvas c,float x,float y,float k,float g,float l){line(c,x-g-l,y,x-g,y);line(c,x+g,y,x+g+l,y);line(c,x,y-g-l,x,y-g);line(c,x,y+g,x,y+g+l);}
    void circle(Canvas c,float x,float y,float k,float g,float l){classic(c,x,y,k,g,l);c.drawCircle(x,y,g*1.55f,p);}
    void dot(Canvas c,float x,float y,float k,float g,float l){classic(c,x,y,k,g,l);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,Math.max(2,size*.055f),p);p.setStyle(Paint.Style.STROKE);}
    void brackets(Canvas c,float x,float y,float k,float g,float l){line(c,x-g-l,y-g,x-g,y-g);line(c,x-g-l,y+g,x-g,y+g);line(c,x+g,y-g,x+g+l,y-g);line(c,x+g,y+g,x+g+l,y+g);}
    void chevron(Canvas c,float x,float y,float k,float g,float l){line(c,x-l,y-l,x,y-g);line(c,x,y-g,x+l,y-l);line(c,x-l,y+l,x,y+g);line(c,x,y+g,x+l,y+l);}
    void x(Canvas c,float x,float y,float k,float g,float l){line(c,x-g-l,y-g-l,x-g,y-g);line(c,x+g,y+g,x+g+l,y+g+l);line(c,x+g,y-g,x+g+l,y-g-l);line(c,x-g-l,y+g+l,x-g,y+g);}
    void tShape(Canvas c,float x,float y,float k,float g,float l){line(c,x-l,y-g,x+l,y-g);line(c,x,y-g,x,y+l);line(c,x-l,y+l,x+l,y+l);}
    void square(Canvas c,float x,float y,float k,float g,float l){float q=g+l; c.drawRect(x-q,y-q,x+q,y+q,p); p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,Math.max(2,size*.035f),p);p.setStyle(Paint.Style.STROKE);}
    void diamond(Canvas c,float x,float y,float k,float g,float l){Path z=new Path();float q=g+l;z.moveTo(x,y-q);z.lineTo(x+q,y);z.lineTo(x,y+q);z.lineTo(x-q,y);z.close();c.drawPath(z,p);}
    void spinner(Canvas c,float x,float y,float k,float g,float l){c.drawCircle(x,y,g+l,p);c.drawCircle(x,y,g*.45f,p);}

    static String styleName(int i){
        String[] n={"Classic","Circle","Dot","Brackets","Chevron","X-Focus","T-Frame","Square","Diamond","Spinner"};
        return n[i%10]+" "+(i/10+1);
    }
}