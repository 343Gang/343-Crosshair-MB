package com.mb343.crosshair;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list;
    TextView title, status;
    SeekBar sizeBar, opacityBar;
    int selected = 0, size = 90, opacity = 100;
    int color = Color.WHITE;
    final String[] colors = {"#FFFFFF","#24A8FF","#45FFB0","#FF4D6D","#FFD166","#B388FF"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showSplash();
    }

    void showSplash() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(Color.rgb(5,10,16));
        TextView t = new TextView(this);
        t.setText("343");
        t.setTextColor(Color.WHITE);
        t.setTextSize(58);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(null, 1);
        f.addView(t, new FrameLayout.LayoutParams(-1,-1));
        setContentView(f);
        t.setScaleX(.2f); t.setScaleY(.2f); t.setAlpha(.1f);
        t.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(850).withEndAction(() -> {
            t.setText("343 CROSSHAIRS");
            t.setTextSize(30);
            t.animate().alpha(0f).setDuration(350).withEndAction(this::buildUI).start();
        }).start();
    }

    TextView tv(String s, float sp) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(Color.WHITE); v.setTextSize(sp);
        v.setPadding(20,12,20,12); return v;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackgroundColor(Color.rgb(13,31,48));
        return b;
    }

    void buildUI() {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22,20,22,30); root.setBackgroundColor(Color.rgb(5,10,16));
        sv.addView(root); setContentView(sv);

        title = tv("343 CROSSHAIRS", 28); title.setTypeface(null,1); title.setTextColor(Color.rgb(36,168,255));
        root.addView(title);
        TextView sub = tv("MB • 100+ gaming crosshairs • Android overlay", 13);
        sub.setTextColor(Color.rgb(142,164,184)); root.addView(sub);

        status = tv("● Overlay OFF", 14); status.setTextColor(Color.rgb(255,90,110)); root.addView(status);

        Button permission = btn("DISPLAY OVER OTHER APPS");
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:"+getPackageName())));
            } else Toast.makeText(this,"Overlay permission is already ON",Toast.LENGTH_SHORT).show();
        });
        root.addView(permission);

        Button start = btn("START / STOP CROSSHAIR");
        start.setOnClickListener(v -> toggleOverlay());
        root.addView(start);

        root.addView(tv("CROSSHAIR LIBRARY",18));
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        makeLibrary();

        root.addView(tv("CUSTOM CROSSHAIR",18));
        root.addView(tv("Selected #"+(selected+1)+" • Use the controls below, then START.",13));

        sizeBar = new SeekBar(this); sizeBar.setMax(160); sizeBar.setProgress(size-40);
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){ size=p+40; save(); }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        root.addView(tv("Size",13)); root.addView(sizeBar);

        opacityBar = new SeekBar(this); opacityBar.setMax(100); opacityBar.setProgress(opacity);
        opacityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){ opacity=Math.max(10,p); save(); }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        root.addView(tv("Opacity",13)); root.addView(opacityBar);

        LinearLayout colorsRow = new LinearLayout(this);
        for(String c:colors){
            Button cb=btn("●"); cb.setTextColor(Color.parseColor(c));
            cb.setOnClickListener(v->{ color=Color.parseColor(c); save(); });
            colorsRow.addView(cb,new LinearLayout.LayoutParams(0,55,1));
        }
        root.addView(tv("Color",13)); root.addView(colorsRow);

        root.addView(tv("POSITION",18));
        LinearLayout arrows = new LinearLayout(this);
        String[] a={"←","↑","CENTER","↓","→"};
        for(String x:a){
            Button q=btn(x); q.setOnClickListener(v->nudge(x));
            arrows.addView(q,new LinearLayout.LayoutParams(0,58,1));
        }
        root.addView(arrows);

        TextView note=tv("Tip: normal overlay mode is touch-through, so the game receives your touches. Use the position buttons to nudge the crosshair.",12);
        note.setTextColor(Color.rgb(142,164,184)); root.addView(note);

        Button reset=btn("RESET POSITION / SETTINGS");
        reset.setOnClickListener(v->{getPreferences(0).edit().clear().apply(); selected=0;size=90;opacity=100;color=Color.WHITE; sizeBar.setProgress(50);opacityBar.setProgress(100);save();});
        root.addView(reset);
    }

    void makeLibrary() {
        list.removeAllViews();
        for(int i=0;i<100;i++){
            final int id=i;
            Button b=btn(String.format(Locale.US,"CROSSHAIR %03d   •   %s",i+1,CrosshairView.styleName(i)));
            b.setOnClickListener(v->{selected=id; save(); Toast.makeText(this,"Crosshair "+(id+1)+" selected",Toast.LENGTH_SHORT).show();});
            list.addView(b);
        }
    }

    void save() {
        getPreferences(0).edit().putInt("id",selected).putInt("size",size).putInt("opacity",opacity).putInt("color",color).apply();
        getSharedPreferences("overlay",0).edit().putInt("id",selected).putInt("size",size).putInt("opacity",opacity).putInt("color",color).apply();
        Intent i=new Intent(this,OverlayService.class); i.setAction("UPDATE"); startService(i);
    }

    void toggleOverlay() {
        if(!Settings.canDrawOverlays(this)){
            Toast.makeText(this,"Turn ON Display over other apps first",Toast.LENGTH_LONG).show(); return;
        }
        Intent i=new Intent(this,OverlayService.class); i.setAction("TOGGLE"); startService(i);
        status.setText("● Overlay toggled");
        status.setTextColor(Color.rgb(69,255,176));
    }

    void nudge(String d) {
        Intent i=new Intent(this,OverlayService.class); i.setAction("NUDGE"); i.putExtra("dir",d); startService(i);
    }
}